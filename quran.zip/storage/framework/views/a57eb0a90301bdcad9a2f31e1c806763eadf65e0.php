<?php
    $descriptionAbove = $getDescriptionAbove();
    $descriptionBelow = $getDescriptionBelow();
?>

<div
    <?php echo e($attributes->merge($getExtraAttributes())->class([
        'filament-tables-text-column px-4 py-3',
        'text-primary-600 transition hover:underline hover:text-primary-500 focus:underline focus:text-primary-500' => $getAction() || $getUrl(),
        'whitespace-normal' => $canWrap(),
    ])); ?>

>
    <?php if(filled($descriptionAbove)): ?>
        <span class="block text-sm text-gray-400">
            <?php echo e($descriptionAbove instanceof \Illuminate\Support\HtmlString ? $descriptionAbove : \Illuminate\Support\Str::of($descriptionAbove)->markdown()->sanitizeHtml()->toHtmlString()); ?>

        </span>
    <?php endif; ?>

    <?php echo e($getFormattedState()); ?>


    <?php if(filled($descriptionBelow)): ?>
        <span class="block text-sm text-gray-400">
            <?php echo e($descriptionBelow instanceof \Illuminate\Support\HtmlString ? $descriptionBelow : \Illuminate\Support\Str::of($descriptionBelow)->markdown()->sanitizeHtml()->toHtmlString()); ?>

        </span>
    <?php endif; ?>
</div>
<?php /**PATH C:\D\myproject\quran\vendor\filament\tables\src\/../resources/views/columns/text-column.blade.php ENDPATH**/ ?>