<h1 <?php echo e($attributes->class(['text-2xl font-bold tracking-tight md:text-3xl filament-header-heading'])); ?>>
    <?php echo e($slot); ?>

</h1>
<?php /**PATH C:\D\myproject\quran\vendor\filament\filament\src\/../resources/views/components/header/heading.blade.php ENDPATH**/ ?>