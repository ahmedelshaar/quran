<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">اضافة شيخ</h4>
                </div>
                <div class="card-body">
                    <div class="info-container">
                        <ul class="list-unstyled">
                            <li class="mb-75">
                                <span class="fw-bolder me-25">الاسم:</span>
                                <span><?php echo e($sheikh->name); ?></span>
                            </li>
                            <li class="mb-75">
                                <span class="fw-bolder me-25">الكنية:</span>
                                <span><?php echo e($sheikh->nickname); ?></span>
                            </li>
                            <li class="mb-75">
                                <span class="fw-bolder me-25">الدولة:</span>
                                <span class="badge bg-light-success"><?php echo e($sheikh->country->name); ?></span>
                            </li>
                            <li class="mb-75">
                                <span class="fw-bolder me-25">ملاحظات:</span>
                                <span><?php echo e($sheikh->notes); ?></span>
                            </li>
                        </ul>
                        <div class="col-12">
                            <a href="<?php echo e(route('sheikh.edit', $sheikh->id)); ?>">
                                <button class="btn btn-warning ms-auto"><span>تعديل</span></button>
                            </a>
                            <div class="d-inline-block">
                                <form method="post" action="<?php echo e(route('sheikh.destroy', $sheikh)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger ms-auto"><span>حذف الشيخ</span></button>
                                </form>
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\D\myproject\quran\resources\views/admin/skeikh/show.blade.php ENDPATH**/ ?>