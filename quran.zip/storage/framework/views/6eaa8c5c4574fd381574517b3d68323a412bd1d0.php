<?php $__env->startSection('content'); ?>
    <section class="app-user-list">
        <div class="card" >
            <div class="card-body border-bottom">
                <div class="row">
                    <div class="col-md-6">
                        <h4 class="card-title">الشيوخ</h4>
                    </div>
                    <div class="col-md-6">
                        <a href="<?php echo e(route('sheikh.create')); ?>">
                            <button class="d-block add-new btn btn-primary ms-auto"><span>اضافة شيخ جديد</span></button>
                        </a>
                    </div>
                    <div class="col-md-12">
                        <?php if(session()->has('message')): ?>
                            <div class="alert alert-success px-2 py-1">
                                <?php echo e(session()->get('message')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="card-datatable table-responsive pt-0">
                <table class="user-list-table table">
                    <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>الاسم</th>
                        <th>اجراء</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $sheikhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sheikh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($sheikh->id); ?></td>
                        <td><?php echo e($sheikh->name); ?></td>
                        <td>
                            <a href="<?php echo e(route('sheikh.show', $sheikh->id)); ?>">
                                <button class="btn btn-primary ms-auto"><span>عرض الشيخ</span></button>
                            </a>
                            <a href="<?php echo e(route('sheikh.edit', $sheikh->id)); ?>">
                                <button class="btn btn-warning ms-auto"><span>تعديل</span></button>
                            </a>
                            <div class="d-inline-block">
                                <form method="post" action="<?php echo e(route('sheikh.destroy', $sheikh)); ?>">
                                    <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger ms-auto"><span>حذف الشيخ</span></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="d-flex justify-content-center">
            <?php echo $sheikhs->links(); ?>

        </div>
    <!-- list and filter end -->
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\D\myproject\quran\resources\views/admin/skeikh/index.blade.php ENDPATH**/ ?>