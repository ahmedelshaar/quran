<?php

namespace App\Filament\Resources\SanadTypeResource\Pages;

use App\Filament\Resources\SanadTypeResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSanadType extends CreateRecord
{
    protected static string $resource = SanadTypeResource::class;
}
