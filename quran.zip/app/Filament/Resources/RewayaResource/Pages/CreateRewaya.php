<?php

namespace App\Filament\Resources\RewayaResource\Pages;

use App\Filament\Resources\RewayaResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRewaya extends CreateRecord
{
    protected static string $resource = RewayaResource::class;
}
