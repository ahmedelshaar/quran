<?php

namespace App\Filament\Resources\SheikhResource\Pages;

use App\Filament\Resources\SheikhResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSheikh extends CreateRecord
{
    protected static string $resource = SheikhResource::class;
}
